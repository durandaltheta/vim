vim7.4-rpms-for-centos6.x
=========================

Vim 7.4 rpm packages for Centos / RHEL 6.x.

Note: __For x86_64 only__.

Source code is taken from Centos 7.0:

    http://vault.centos.org/7.0.1406/os/Source/SPackages/

To install:

    rpm -Uvh vim-common-7.4.160-1.el6.x86_64.rpm vim-filesystem-7.4.160-1.el6.x86_64.rpm vim-enhanced-7.4.160-1.el6.x86_64.rpm
    
    
or:

    rpm -Uvh *
    

runsisi@hust.edu.cn
